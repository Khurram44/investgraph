import React from 'react';
import ReactDOM from 'react-dom';
import Widget from './widget';

ReactDOM.render(<Widget />, document.getElementById('widget-container'));