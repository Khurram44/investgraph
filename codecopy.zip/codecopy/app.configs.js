export const variables = {
    baseOrign: window.location.origin,
    scopeOrigin:"U2FsdGVkX19IFcUPFt1UJ3/0WodMap1OmE5GsuBmEnKU5PpcpYSc4nKJBrk5dVgxazguX0+4ym4dW7fYyg46Dg==",
    scopeOrigins:"U2FsdGVkX18F6+2F/HEYglxPgxAShWtm4FDyg89lRhyLJKWCyNvb6RQqZeFkZo/h"
}
